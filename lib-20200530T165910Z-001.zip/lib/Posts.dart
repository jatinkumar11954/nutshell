class Posts{
  String postImage, title, date, time, description, category;

  Posts(this.postImage, this.title, this.date, this.time, this.description, this.category);
}